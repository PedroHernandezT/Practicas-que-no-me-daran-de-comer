<?php include './cabecera.php';?>
<?php
//debemos revisar si los input tienen informacion
//isset(what we check)-?-if true-:-if false;


$txtID = (isset($_POST['txtID']))?$_POST['txtID']:""; //['nombre/id de su input en el formulario']
$txtCliente = (isset($_POST['txtCliente']))?$_POST['txtCliente']:"";
$txtServicio = (isset($_POST['txtServicio']))?$_POST['txtServicio']:"";
$txtComentario = (isset($_POST['txtComentario']))?$_POST['txtComentario']:"";

$accion = (isset($_POST['accion']))?$_POST['accion']:"";
 switch ($accion) {
	case 'add':
		$sentenciaSQL = $pdo->prepare("INSERT INTO cotizaservicio (ClienteID, ServicioID, Cantidad) 
		VALUES (:clienteid, :servicioid, :comentario);"); 
			
			$sentenciaSQL->bindParam(':clienteid', $txtCliente);
			$sentenciaSQL->bindParam(':servicioid', $txtServicio);
			$sentenciaSQL->bindParam(':comentario', $txtComentario);
			$sentenciaSQL->execute();
			header('Location: index6.php');
		// code...
		echo "Click on add";
	break;
	
	case 'Cancel':
		// code...
		header('Location: index6.php');
	break;
	case 'Select':
			$sentenciaSQL = $pdo->prepare("SELECT * FROM cotizaservicio WHERE CotizacionServicioID=:id");
			$sentenciaSQL->bindParam(':id', $txtID);
			$sentenciaSQL->execute();
			$Producto=$sentenciaSQL->fetch(PDO::FETCH_LAZY);
			$txtCliente=$Producto['ClienteID'];
			$txtServicio=$Producto['ServicioID'];
			$txtComentario=$Producto['Cantidad'];
	break;
			
	case 'Modify':
		$sentenciaSQL = $pdo->prepare("UPDATE cotizaservicio SET Cantidad= :comentario, ClienteID= :clienteid, ServicioID=:servicioid WHERE CotizacionServicioID=:id"); 
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->bindParam(':clienteid', $txtCliente);
				$sentenciaSQL->bindParam(':servicioid', $txtServicio);
				$sentenciaSQL->bindParam(':comentario', $txtComentario);
				$sentenciaSQL->execute();
				header('Location: index6.php');
	break;

	case 'Delete':
		$sentenciaSQL = $pdo->prepare("DELETE FROM cotizaservicio WHERE CotizacionServicioID=:id");
		$sentenciaSQL->bindParam(':id', $txtID);
		$sentenciaSQL->execute();
	break;

} 

?>
<body>
<div class="wrapper">

	<?php include './menu.php';?>

	
	<div class="main-panel">
		<div class="content">
			<div class="container-fluid">
				<h4 class="page-title">Cotización Servicios</h4>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-body">
									<form method="POST" enctype="multipart/form-data">  <!--change method to POST, we use enctype to allow file submission-->
										
										<div class="container">
											<div class="row">
												<div class="col-md-12">
														<br/>
													<div class="card">
														<div class="card-header">
															Servicio Cotización data
														</div>
														<div class="card-body">
															<form method="POST" enctype="multipart/form-data">  <!--change method to POST, we use enctype to allow file submission-->
                                                            <div class="form-group">
                                                                <label for="txtCliente">Cliente</label>
																<input type="hidden" name="txtID" value="<?php echo $txtID;?>">
                                                                <select class="form-control" name="txtCliente"  id="txtCliente">       
                                                                    <option value="00">-- Seleccionar --</option>

                                                                    <?php 
                                                                        $sentenciaCategories = $pdo->prepare("SELECT * from cliente;");
                                                                        $sentenciaCategories->execute();
                                                                        
                                                                        if(!empty($txtCliente))
                                                                        {
                                                                            $ListCategories=$sentenciaCategories->fetchAll();
                                                                            foreach ($ListCategories as $category) 
                                                                            { 
                                                                                $selected = ($txtCliente == $category['ClienteID']) ? ' selected' : null;
                                                                                echo '<option value="'.$category['ClienteID'].'"'.$selected.'>'.$category['Nombre'].'</option>';
                                                                            }
                                                                        }
                                                                        else
                                                                            {
                                                                                $ListCategories=$sentenciaCategories->fetchAll();
                                                                                foreach ($ListCategories as $category) { 
                                                                                echo '<option value="'.$category['ClienteID'].'">'.$category['Nombre'].'</option>';
                                                                            }
                                                                        }
                                                                    ?>
                                                                </select>
                                                            </div>
														<div class="form-group">
                                                                <label for="txtServicio">Servicio</label>
                                                            
                                                                <select class="form-control" name="txtServicio"  id="txtServicio">       
                                                                    <option value="00">-- Seleccionar --</option>

                                                                    <?php 
                                                                        $sentenciaCategories = $pdo->prepare("SELECT * from servicio;");
                                                                        $sentenciaCategories->execute();
                                                                        
                                                                        if(!empty($txtServicio))
                                                                        {
                                                                            $ListCategories=$sentenciaCategories->fetchAll();
                                                                            foreach ($ListCategories as $category) 
                                                                            { 
                                                                                $selected = ($txtServicio == $category['ServicioID']) ? ' selected' : null;
                                                                                echo '<option value="'.$category['ServicioID'].'"'.$selected.'>'.$category['NombreServicio'].'</option>';
                                                                            }
                                                                        }
                                                                        else
                                                                            {
                                                                                $ListCategories=$sentenciaCategories->fetchAll();
                                                                                foreach ($ListCategories as $category) { 
                                                                                echo '<option value="'.$category['ServicioID'].'">'.$category['NombreServicio'].'</option>';
                                                                            }
                                                                        }
                                                                    ?>
                                                                </select>
                                                        </div>
																<div class="form-group">
																	<label for="txtComentario">Cantidad</label>
																	<input type="text" name="txtComentario" value="<?php echo $txtComentario; ?>" id="txtComentario" class="form-control progress-table-wrap" 
																	placeholder="Comentario">
																</div>

                                                                <div class="btn-group" role="group">		
																	<button type="submit" name="accion" value="add" class="btn btn-success">Add</button> 
																	<button type="submit" name="accion" value="Modify" class="btn btn-primary">Modify</button>				
																	<button type="submit" name="accion" value="Cancel" class="btn btn-danger">Cancel</button>
                                                                </div>
									</form>
								</div>
							</div>
						</div>
					</div>
				



				<?php
				$sentenciaSQL = $pdo->prepare("SELECT * FROM cotizaservicio");
				$sentenciaSQL->execute();
				$listaProductos=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
				?>
				<div class="row">
					<div class="col-md-12">
						<br/>
						<table class=" MyTable table cell-border display-compact" id="MyTable">
							<thead class="table-head">
								<tr>
								<th>CotizacionServicioID</th>
								<th>Cliente</th>
								<th>Servicio</th>
								<th>Cantidad</th>
								<th>Acciones</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($listaProductos as $producto) {?>
								<tr class="table-row">
								<th><?php echo $producto['CotizacionServicioID'];?></th>
								<td><?php echo $producto['ClienteID'];?></td>
								<td><?php echo $producto['ServicioID'];?></td>
								<td><?php echo $producto['Cantidad'];?></td>

								<td><form method="post">
									<input type="hidden" name="txtID" value="<?php echo $producto['CotizacionServicioID']?>">
									<input type="submit" name="accion" value="Select" class="btn btn-primary">
									<input type="submit" name="accion" value="Delete" class="btn btn-danger">
								</form></td>
								</tr>
							<?php }?>
							</tbody>
						</table>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>

<?php include './footer.php';?>
<script>
$(document).ready(function () {
$('#MyTable').DataTable();
});
</script>
</body>