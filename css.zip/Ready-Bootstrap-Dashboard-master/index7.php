<?php include './cabecera.php';?>
<?php

//debemos revisar si los input tienen informacion
//isset(what we check)-?-if true-:-if false;


        $txtID = (isset($_POST['txtID']))?$_POST['txtID']:""; //['nombre/id de su input en el formulario']
        $txtName = (isset($_POST['txtName']))?$_POST['txtName']:"";
        $txtCategory = (isset($_POST['txtCategory']))?$_POST['txtCategory']:"";
		$txtDescription = (isset($_POST['txtDescription']))?$_POST['txtDescription']:"";
		$txtEmail= (isset($_POST['txtEmail']))?$_POST['txtEmail']:"";
		$password_hash = password_hash($txtDescription, PASSWORD_BCRYPT);


        $accion = (isset($_POST['accion']))?$_POST['accion']:"";
		switch ($accion) {
			case 'add':
				$sentenciaSQL = $pdo->prepare("INSERT INTO usuario (Contrasena, TipoUsuario_ID, Usuario, Email ) VALUES (:contrasena, :tipousuarioid, :usuario, :email );"); 
				
				$sentenciaSQL->bindParam(':contrasena', $password_hash);
				$sentenciaSQL->bindParam(':tipousuarioid', $txtCategory);
				$sentenciaSQL->bindParam(':usuario', $txtName);
				$sentenciaSQL->bindParam(':email', $txtEmail);
				$sentenciaSQL->execute();
				header('Location: index7.php');
				// code...
				echo "Click on add";
			break;
			
			case 'Cancel':
				header('Location: index7.php');
				break;
			case 'Seleccionar':
				$sentenciaSQL = $pdo->prepare("SELECT * FROM usuario WHERE UsuarioID=:id");
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->execute();
				$UnProducto=$sentenciaSQL->fetch(PDO::FETCH_LAZY);
				$txtEmail=$UnProducto['Email'];
				$txtName=$UnProducto['Usuario'];
				$txtDescription=$UnProducto['Contrasena'];
				$txtCategory=$UnProducto['TipoUsuario_ID'];
				break;
			case 'Modificar':
				$sentenciaSQL = $pdo->prepare("UPDATE usuario SET Contrasena = :contrasena , TipoUsuario_ID = :tipousuarioid, 
				Usuario = :usuario, Email = :email WHERE UsuarioID=:id"); 
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->bindParam(':contrasena', $txtDescription);
				$sentenciaSQL->bindParam(':tipousuarioid', $txtCategory);
				$sentenciaSQL->bindParam(':usuario', $txtName);
				$sentenciaSQL->bindParam(':email', $txtEmail);
				$sentenciaSQL->execute();	
				header('Location: index7.php');
				break;

			case 'Eliminar':
				$sentenciaSQL = $pdo->prepare("DELETE FROM usuario WHERE UsuarioID=:id");
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->execute();
				break;
		} 
        
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Frigaa Soluciones</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  </head>
<body>
<div class="wrapper">

	<?php include './menu.php';?>
	
	<div class="main-panel">
		<div class="content">
			<div class="container-fluid">
				<h4 class="page-title">Usuarios</h4>
					<div class="row">
						<div class="col-md-12">
								<br/>
							<div class="card">
								<div class="card-header">
									Datos del Usuario
								</div>
								<div class="card-body">
									<form method="POST" enctype="multipart/form-data">  <!--change method to POST, we use enctype to allow file submission-->
										<div class="form-group">
                
											<label for="txtEmail">Email</label>
											<input type="text" name="txtEmail" id="txtEmail" value="<?php echo $txtEmail; ?>" class="form-control single-input" placeholder="Email">
                                        </div>
										<div class="form-group">
										<input type="hidden" name="txtID" value="<?php echo $txtID;?>">
											<label for="txtName">Usuario</label>
											<input type="text" name="txtName" value="<?php echo $txtName; ?>" id="txtName" class="form-control progress-table-wrap" 
											placeholder="Nombre de usuario">
                                        </div>
										<div class="form-group">
                
											<label for="txtDescription">Contraseña</label>
											<input type="text" name="txtDescription" id="txtDescription" value="<?php echo $txtDescription; ?>" class="form-control single-input" placeholder="Contraseña">
                                        </div>
										<div class="form-group">
																<label for="txtCategory">Categorias</label>
																<?php echo $txtCategory; ?>
																<input type="hidden" name="txtOldCategory" id="" value="<?php echo $txtCategory; ?>" class="form-control" placeholder="Image">
															
																<select class="form-control" name="txtCategory"  id="txtCategory">       
																	<option value="00">-- Seleccionar --</option>

																	<?php 
																		$sentenciaCategories = $pdo->prepare("SELECT * from tipo_usuario;");
																		$sentenciaCategories->execute();
																		
																		if(!empty($txtCategory))
																		{
																			$ListCategories=$sentenciaCategories->fetchAll();
																			foreach ($ListCategories as $category) 
																			{ 
																				$selected = ($txtCategory == $category['TipoUsuario_ID']) ? ' selected' : null;
																				echo '<option value="'.$category['TipoUsuario_ID'].'"'.$selected.'>'.$category['Tipo_usuario'].'</option>';
																			}
																		}
																		else
																			{
																				$ListCategories=$sentenciaCategories->fetchAll();
																				foreach ($ListCategories as $category) { 
																				echo '<option value="'.$category['TipoUsuario_ID'].'">'.$category['Tipo_usuario'].'</option>';
																			}
																		}
																	?>
																</select>
															</div>

										
										
									
										<div class="btn-group" role="group">		
											<button type="submit" name="accion" value="add" class="btn btn-success">Agregar</button> 
										    <button type="submit" name="accion" value="Modificar" class="btn btn-primary">Modificar</button> 
											<button type="submit" name="accion" value="Cancel" class="btn btn-danger">Cancelar</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				



				<?php
				$sentenciaSQL = $pdo->prepare("SELECT * FROM usuario");
				$sentenciaSQL->execute();
				$listaProductos=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
				?>
				<div class="row">
					<div class="col-md-12">
						<br/>
						<table class="MyTable  table cell-border display-compact" id="MyTable">
							<thead class="table-head">
								<tr>
								<th>ID</th>
								<th>Usuario</th>
								<th>Email</th>
								<th>Contraseña</th>
								<th>Categoria</th>
								<th>Acciones</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($listaProductos as $producto) {?>
								<tr class="table-row">
								<th><?php echo $producto['UsuarioID'];?></th>
								<th><?php echo $producto['Usuario'];?></th>
								<th><?php echo $producto['Email'];?></th>
								<td><?php echo $producto['Contrasena'];?></td>
								<td><?php echo $producto['TipoUsuario_ID'];?></td>
								<td><form method="post">
									<input type="hidden" name="txtID" value="<?php echo $producto['UsuarioID']?>">
									<input type="submit" name="accion" value="Seleccionar" class="btn btn-primary">
									<input type="submit" name="accion" value="Eliminar" class="btn btn-danger">
								</form></td>
								</tr>
							<?php }?>
							</tbody>
						</table>
					</div>
					</div>
					
			</div>
		</div>
	</div>
</div>

<?php include './footer.php';?>
<script>
$(document).ready(function () {
$('#MyTable').DataTable();
});
</script>

</body>