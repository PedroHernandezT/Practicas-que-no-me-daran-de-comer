<?php
define("SERVER", "69.49.241.61");
define("USER", "frigaaso_admin");
define("PASSWORD", "BTb?o;rVCWaL");
define("DB", "frigaaso_frigaasolucionesdb");
?>