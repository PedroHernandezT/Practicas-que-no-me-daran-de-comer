
<?php include './cabecera.php';?>
<?php
//debemos revisar si los input tienen informacion
//isset(what we check)-?-if true-:-if false;


        $txtID = (isset($_POST['txtID']))?$_POST['txtID']:""; //['nombre/id de su input en el formulario']
        $txtName = (isset($_POST['txtName']))?$_POST['txtName']:"";
        $txtDescription = (isset($_POST['txtDescription']))?$_POST['txtDescription']:"";
        $txtCategory = (isset($_POST['txtCategory']))?$_POST['txtCategory']:"";
        $txtPrice = (isset($_POST['txtPrice']))?$_POST['txtPrice']:"";
        $txtImage = (isset($_FILES['txtImage']['name']))?$_FILES['txtImage']['name']:"";//aqui se usa $_FILES
		$txtOldImg=(isset($_POST['txtOldImg']))?$_POST['txtOldImg']:"";
		
                    
                 

        $accion = (isset($_POST['accion']))?$_POST['accion']:"";
		 switch ($accion) {
			case 'add':
				$sentenciaSQL = $pdo->prepare("INSERT INTO preoducto (NombreProducto, CategoriaID , Descripcion, 
				`PrecioProducto`, `ProductoImagen`) VALUES (:nombreproducto, :categoriaid, :descripcion, 
				:precioproducto, :productoimagen);"); 
				$date = new DateTime();
				
				$ImgFileName =($txtImage!="")?$date->getTimestamp()."_".$_FILES["txtImage"]["name"]:"image.jpg";
				
				$ImgTmp=$_FILES["txtImage"]["tmp_name"];
				
				if($ImgTmp!=""){
					move_uploaded_file($ImgTmp, "images/productos/".$ImgFileName);
				}
				$sentenciaSQL->bindParam(':nombreproducto', $txtName);
				$sentenciaSQL->bindParam(':categoriaid', $txtCategory);
				$sentenciaSQL->bindParam(':descripcion', $txtDescription);
				$sentenciaSQL->bindParam(':precioproducto', $txtPrice);
				$sentenciaSQL->bindParam(':productoimagen', $ImgFileName);
				$sentenciaSQL->execute();
				header('Location: index2.php');
				
				// code...
				echo "Click on add";
			break;
			
			case 'Cancel':
				header('Location: index2.php');
				// code...
				break;
			case 'Seleccionar':
				$sentenciaSQL = $pdo->prepare("SELECT * FROM preoducto WHERE ProductoID=:id");
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->execute();
				$UnProducto=$sentenciaSQL->fetch(PDO::FETCH_LAZY);
				$txtName=$UnProducto['NombreProducto'];
				$txtCategory=$UnProducto['CategoriaID'];
				$txtDescription=$UnProducto['Descripcion'];
				$txtPrice=$UnProducto['PrecioProducto'];
				$txtImage=$UnProducto['ProductoImagen'];
				$txtOldImg=$UnProducto['ProductoImagen'];

				
				break;

			case 'Modificar':
				$sentenciaSQL = $pdo->prepare("UPDATE preoducto SET NombreProducto = :nombreproducto, CategoriaID = :categoriaid, 
				Descripcion = :descripcion, PrecioProducto= :precioproducto WHERE ProductoID=:id"); 
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->bindParam(':nombreproducto', $txtName);
				$sentenciaSQL->bindParam(':categoriaid', $txtCategory);
				$sentenciaSQL->bindParam(':descripcion', $txtDescription);
				$sentenciaSQL->bindParam(':precioproducto', $txtPrice);
				$sentenciaSQL->execute();
			if($txtImage!="")
			{
				$date = new DateTime();
				//creacion del nuevo nombre de la imagen
				$ImgFileName =($txtImage!="")?$date->getTimestamp()."_".$_FILES["txtImage"]["name"]:"image.jpg";
				$ImgTmp=$_FILES["txtImage"]["tmp_name"];
				move_uploaded_file($ImgTmp, "images/productos/".$ImgFileName);
	
				$sentenciaSQL = $pdo->prepare("SELECT ProductoImagen FROM preoducto WHERE ProductoID=:id");
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->execute();
	
				$product=$sentenciaSQL->fetch(PDO::FETCH_LAZY);
				if(isset($product["ProductoImagen"]) && ($product["ProductoImagen"]!="image.jpg")){
					if(file_exists("images/productos/".$product["ProductoImagen"])){
						unlink("images/productos/".$product["ProductoImagen"]);
					}
				}
			$sentenciaSQL = $pdo->prepare("UPDATE preoducto SET ProductoImagen = :productoimagen WHERE ProductoID=:id");  
			$sentenciaSQL->bindParam(':productoimagen', $ImgFileName); 
			$sentenciaSQL->bindParam(':id', $txtID);
			$sentenciaSQL->execute();
	
			}else
			{
			$sentenciaSQL = $pdo->prepare("UPDATE preoducto SET ProductoImagen = :productoimagen WHERE ProductoID=:id"); 
			$sentenciaSQL->bindParam(':productoimagen', $txtOldImg); 
			$sentenciaSQL->bindParam(':id', $txtID);
			$sentenciaSQL->execute();
			}
			
			//redirigir a la misma pagina 
			header('Location: index2.php');
			
			
			break;
				break;

		
			case 'Eliminar':
				$sentenciaSQL = $pdo->prepare("SELECT ProductoImagen FROM preoducto WHERE ProductoID=:id");
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->execute();
				$product=$sentenciaSQL->fetch(PDO::FETCH_LAZY);
				if(isset($product["ProductoImagen"]) && ($product["ProductoImagen"]!="image.jpg")){
					if(file_exists("images/productos/".$product["ProductoImagen"])){
						unlink("images/productos/".$product["ProductoImagen"]);
					}
				}
				$sentenciaSQL = $pdo->prepare("DELETE FROM preoducto WHERE ProductoID=:id");
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->execute();
				header('Location: index2.php');
				break;
		} 
?>
<body>
<div class="wrapper">

	<?php include './menu.php';?>

	
	<div class="main-panel">
		<div class="content">
			<div class="container-fluid">
				<h4 class="page-title">Productos</h4>
					<div class="row">
						<div class="col-md-12">
								<br/>
							<div class="card">
								<div class="card-header">
									Datos del producto
								</div>
								<div class="card-body">
									<form method="POST" enctype="multipart/form-data">  <!--change method to POST, we use enctype to allow file submission-->
										
										<div class="form-group">
										    <input type="hidden" name="txtID" value="<?php echo $txtID;?>">
											<label for="txtName">Nombre</label>
											<input type="text" name="txtName" id="txtName" value="<?php echo $txtName; ?>" class="form-control single-input" placeholder="Nombre">
                                        </div>

										<div class="form-group">
											<label for="txtPrice">Precio</label>
											<input type="text" name="txtPrice" id="txtPrice" value="<?php echo $txtPrice; ?>" class="form-control progress-table-wrap" placeholder="Precio Producto">
                                        </div>
										<div class="form-group">
											<label for="txtDescription">Descripcion</label>
											<input type="text" name="txtDescription" value="<?php echo $txtDescription; ?>" id="txtDescription" class="form-control progress-table-wrap" 
											placeholder="Descripción del producto">
                                        </div>
										<div class="form-group">
																<label for="txtCategory">Categorias</label>
																<?php echo $txtCategory; ?>
																<input type="hidden" name="txtOldCategory" id="" value="<?php echo $txtCategory; ?>" class="form-control" placeholder="Image">
															
																<select class="form-control" name="txtCategory"  id="txtCategory">       
																	<option value="00">-- Seleccionar --</option>

																	<?php 
																		$sentenciaCategories = $pdo->prepare("SELECT * from categoria;");
																		$sentenciaCategories->execute();
																		
																		if(!empty($txtCategory))
																		{
																			$ListCategories=$sentenciaCategories->fetchAll();
																			foreach ($ListCategories as $category) 
																			{ 
																				$selected = ($txtCategory == $category['CategoriaID']) ? ' selected' : null;
																				echo '<option value="'.$category['CategoriaID'].'"'.$selected.'>'.$category['NombreCategoria'].'</option>';
																			}
																		}
																		else
																			{
																				$ListCategories=$sentenciaCategories->fetchAll();
																				foreach ($ListCategories as $category) { 
																				echo '<option value="'.$category['CategoriaID'].'">'.$category['NombreCategoria'].'</option>';
																			}
																		}
																	?>
																</select>
															</div>

										<div class="form-group">
											<label for="txtImage"></label>
											<?php echo $txtImage; ?>
											<input type="hidden" name="txtOldImg" id="" value="<?php echo $txtImage; ?>" class="form-control" placeholder="Image">
											<input type="file" name="txtImage" id="txtImage" class="form-control" placeholder="Image">
										</div>
									
										<div class="btn-group" role="group">		
											<button type="submit" name="accion" value="add" class="btn btn-success">Agregar</button> 
										    <button type="submit" name="accion" value="Modificar" class="btn btn-primary">Modificar</button>
											<button type="submit" name="accion" value="Cancel" class="btn btn-danger">Cancelar</button>
										</div>
									</form>

								</div>
							</div>
						</div>
					</div>
				



				<?php
				$sentenciaSQL = $pdo->prepare("SELECT * FROM preoducto");
				$sentenciaSQL->execute();
				$listaProductos=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
				?>
				<div class="row">
					<div class="col-md-12">
						<br/>
						<table class="MyTable  table cell-border display-compact" id="MyTable">
							<thead class="table-head">
								<tr>
								<th>ID</th>
								<th>Nombre</th>
								<th>Categoria</th>
								<th>Descripcion</th>
								<th>Precio</th>
								<th>Imagen</th>
								<th>Acciones</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($listaProductos as $producto) {?>
								<tr class="table-row">
								<th><?php echo $producto['ProductoID'];?></th>
								<td><?php echo $producto['NombreProducto'];?></td>
								<td><?php echo $producto['CategoriaID'];?></td>
								<td><?php echo $producto['Descripcion']; ?></td>
								<td><?php echo $producto['PrecioProducto'];?></td>
								<td><img src="images/productos/<?php echo $producto['ProductoImagen'];?>" width="250px" height="300px"></td>
								<td><form method="post">
								    
									<input type="hidden" name="txtID" value="<?php echo $producto['ProductoID']?>">
									<input type="submit" name="accion" value="Seleccionar" class="btn btn-primary">
									<input type="submit" name="accion" value="Eliminar" class="btn btn-danger">
								</form></td>
								</tr>
							<?php }?>
							</tbody>
						</table>
					</div>

				</div>
				             
			</div>
		</div>
	</div>
</div>

<?php include './footer.php';?>
<script>
$(document).ready(function () {
$('#MyTable').DataTable();
});
</script>

</body>