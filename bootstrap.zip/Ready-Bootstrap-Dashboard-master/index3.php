<?php include './cabecera.php';?>
<?php
//debemos revisar si los input tienen informacion
//isset(what we check)-?-if true-:-if false;


        $txtID = (isset($_POST['txtID']))?$_POST['txtID']:""; //['nombre/id de su input en el formulario']
        $txtTipo = (isset($_POST['txtTipo']))?$_POST['txtTipo']:"";
        $txtPrecio = (isset($_POST['txtPrecio']))?$_POST['txtPrecio']:"";
		$txtDescripcion = (isset($_POST['txtDescripcion']))?$_POST['txtDescripcion']:"";
        $accion = (isset($_POST['accion']))?$_POST['accion']:"";
		switch ($accion) {
			case 'add':
				$sentenciaSQL = $pdo->prepare("INSERT INTO servicio (Nombreservicio, PrecioServicio, DescripcionServicio )
				 VALUES (:nombreservicio, :precioservicio, :descripcionservicio);"); 
				
				$sentenciaSQL->bindParam(':nombreservicio', $txtTipo);
				$sentenciaSQL->bindParam(':precioservicio', $txtPrecio);
				$sentenciaSQL->bindParam(':descripcionservicio', $txtDescripcion);
				$sentenciaSQL->execute();
				// code...
				echo "Click on add";
			break;
			
			case 'Cancel':
				// code...
				header('Location: index3.php');
				break;
				case 'Select':
					$sentenciaSQL = $pdo->prepare("SELECT * FROM servicio WHERE ServicioID=:id");
					$sentenciaSQL->bindParam(':id', $txtID);
					$sentenciaSQL->execute();
					$Producto=$sentenciaSQL->fetch(PDO::FETCH_LAZY);
					$txtID=$Producto['ServicioID'];
					$txtTipo=$Producto['NombreServicio'];
					$txtPrecio=$Producto['PrecioServicio'];
					$txtDescripcion=$Producto['DescripcionServicio'];
					break;
			case 'Modify':
				// code...
			
				$sentenciaSQL = $pdo->prepare("UPDATE servicio SET NombreServicio = :nombreservicio, 
						PrecioServicio = :precioservicio, DescripcionServicio= :descripcionservicio WHERE ServicioID=:id"); 
						$sentenciaSQL->bindParam(':id', $txtID);
						$sentenciaSQL->bindParam(':nombreservicio', $txtTipo);
						$sentenciaSQL->bindParam(':precioservicio', $txtPrecio);
						$sentenciaSQL->bindParam(':descripcionservicio', $txtDescripcion);
			
						$sentenciaSQL->execute();
						header('Location: index3.php');
			
				break;
		
			case 'Delete':
				$sentenciaSQL = $pdo->prepare("DELETE FROM servicio WHERE ServicioID=:id");
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->execute();
				header('Location: index3.php');
				break;
		} 

?>
<body>
<div class="wrapper">

	<?php include './menu.php';?>

	
	<div class="main-panel">
		<div class="content">
			<div class="container-fluid">
				<h4 class="page-title">Servicios</h4>
					<div class="row">
						<div class="col-md-12">
								<br/>
							<div class="card">
								<div class="card-header">
									Datos del servicio
								</div>
								<div class="card-body">
									<form method="POST" enctype="multipart/form-data">  <!--change method to POST, we use enctype to allow file submission-->
										
										<div class="form-group">
                                        
										
										<label for="txtTipo">Nombre del servicio</label>
										<input type="hidden" name="txtID" value="<?php echo $txtID;?>">
										<input type="text" name="txtTipo" id="txtTipo" value="<?php echo $txtTipo; ?>" class="form-control progress-table-wrap" placeholder="Nombre servicio">
                                        </div>

										<div class="form-group">
											<label for="txtPrecio">Precio del servicio</label>
											<input type="text" name="txtPrecio" id="txtPrecio" value="<?php echo $txtPrecio; ?>" class="form-control progress-table-wrap" placeholder="Precio servicio">
                                        </div>
										<div class="form-group">
											<label for="txtDescripcion">Descripcion del servicio</label>
											<input type="text" name="txtDescripcion" value="<?php echo $txtDescripcion; ?>" id="txtDescripcion" class="form-control progress-table-wrap" 
											placeholder="Descripción del servicio">
                                        </div>
        
                                        </select>
                                
                                        </div>

									
									
										<div class="btn-group" role="group">		
											<button type="submit" name="accion" value="add" class="btn btn-success">Add</button> <!--value must match
											with switch-->
											<button type="submit" name="accion" value="Modify" class="btn btn-primary">Modify</button>
											<button type="submit" name="accion" value="Cancel" class="btn btn-danger">Cancel</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				



				<?php
				$sentenciaSQL = $pdo->prepare("SELECT * FROM servicio");
				$sentenciaSQL->execute();
				$listaProductos=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
				?>
				<div class="row">
					<div class="col-md-12">
						<br/>
						<table class="MyTable  table cell-border display-compact" id="MyTable">
							<thead class="table-head">
								<tr>
								<th>ID</th>
								<th>Nombre</th>
								<th>Precio</th>
								<th>Descripcion</th>
                                <th>Accions</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ($listaProductos as $producto) {?>
								<tr class="table-row">
								<th><?php echo $producto['ServicioID'];?></th>
								<td><?php echo $producto['NombreServicio'];?></td>
								<td><?php echo $producto['PrecioServicio'];?></td>
								<td><?php echo $producto['DescripcionServicio']; ?></td>
								<td><form method="post">
									<input type="hidden" name="txtID" value="<?php echo $producto['ServicioID']?>">
									<input type="submit" name="accion" value="Select" class="btn btn-primary">
									<input type="submit" name="accion" value="Delete" class="btn btn-danger">
								</form></td>
								</tr>
							<?php }?>
							</tbody>
						</table>
					</div>

				</div>

			</div>
		</div>
	</div>
</div>

<?php include './footer.php';?>
<script>
$(document).ready(function () {
$('#MyTable').DataTable();
});
</script>

</body>