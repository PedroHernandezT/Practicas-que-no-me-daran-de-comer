<section>
<div class="main-header">
    <div class="logo-header">
        
            Frigaa Soluciones

        <button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-controls="sidebar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
    </div>
    <nav class="navbar navbar-header navbar-expand-lg">

        <div class="container-fluid">


            <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">

            </ul>
        </div>
    </nav>
</div>
</section>

<div class="sidebar">
    <div class="scrollbar-inner sidebar-wrapper">
        <div class="user">
            <div class="info">
                <a class="" data-toggle="collapse" href="#collapseExample" aria-expanded="true">
                    <span>
                    <?php
session_start();
if(!isset($_SESSION["session_username"])){
    header("Location:login.php");
}
else{
?>
    <div id = "Bienvenido">
        <h2>Bienvenido <span><?php echo $_SESSION['session_username'];?>!</span></h2>
    </div>
    <?php
}
?>

                         <span class="user-level"> <img src="images/img3.jpg" alt="img" width="40px">Administrador</span>
                    </span>
                </a>
                <div class="clearfix"></div>
            </div>
        </div>
        <ul class="nav">
        <li class="nav-item">
                <a href="index7.php">
                    <p>Usuarios</p>
                </a>
            </li> 
            <li class="nav-item active">
                <a href="index1.php">
                    <p>Clientes</p>
                </a>
            </li>
            <li class="nav-item">
                <a href="index2.php">
                    <p>Productos</p>
                </a>
            </li>
            <li class="nav-item">
                <a href="index3.php">
                    <p>Servicios</p>
                </a>
            </li>
            <li class="nav-item">
                <a href="index5.php">
                    <p>Cotizacion Servicios</p>

                </a>
            </li>
            <li class="nav-item">
                <a href="logout.php">
                    <p>Cerrar sesion</p>
                </a>
            </li>
             
            
        </ul>
    </div>
</div>
			
		
