<?php include './cabecera.php';?>
<?php

        $txtID = (isset($_POST['txtID']))?$_POST['txtID']:"";
		$txtNombreUsuario = (isset($_POST['txtNombreUsuario']))?$_POST['txtNombreUsuario']:"";
        $txtNombre = (isset($_POST['txtNombre']))?$_POST['txtNombre']:"";
        $txtApellido = (isset($_POST['txtApellido']))?$_POST['txtApellido']:"";
		$txtCiudad = (isset($_POST['txtCiudad']))?$_POST['txtCiudad']:"";
		$txtCP = (isset($_POST['txtCP']))?$_POST['txtCP']:"";
		$txtTelefono = (isset($_POST['txtTelefono']))?$_POST['txtTelefono']:"";
		$txtContrasena = (isset($_POST['txtContrasena']))?$_POST['txtContrasena']:"";
		$password_hash = password_hash($txtContrasena, PASSWORD_BCRYPT);
		$txtEmail = (isset($_POST['txtEmail']))?$_POST['txtEmail']:"";

        $accion = (isset($_POST['accion']))?$_POST['accion']:"";
		switch ($accion) {
			case 'add':
				$sentenciaSQL = $pdo->prepare("INSERT INTO cliente (NombreUsuario, Nombre, Apellido, Ciudad, CP, Telefono, Contrasena, Email )
				 VALUES (:nombreusuario, :nombre, :apellido, :ciudad, :cp, :telefono, :contrasena, :email);"); 
				$sentenciaSQL->bindParam(':nombreusuario', $txtNombreUsuario);
				$sentenciaSQL->bindParam(':nombre', $txtNombre);
				$sentenciaSQL->bindParam(':apellido', $txtApellido);
				$sentenciaSQL->bindParam(':ciudad', $txtCiudad);
				$sentenciaSQL->bindParam(':cp', $txtCP);
				$sentenciaSQL->bindParam(':telefono', $txtTelefono);
				$sentenciaSQL->bindParam(':contrasena', $password_hash);
				$sentenciaSQL->bindParam(':email', $txtEmail);
				$sentenciaSQL->execute();
				header('Location: index1.php');
				echo "Click on add";
			break;
			case 'Cancel':
				header('Location: index1.php');
				break;
			case 'Select':
				$sentenciaSQL = $pdo->prepare("SELECT * FROM cliente WHERE ClienteID=:id");
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->execute();
				$Producto=$sentenciaSQL->fetch(PDO::FETCH_LAZY);
				$txtID=$Producto['ClienteID'];
				$txtNombreUsuario=$Producto['NombreUsuario'];
				$txtNombre=$Producto['Nombre'];
				$txtApellido=$Producto['Apellido'];
				$txtCiudad=$Producto['Ciudad'];
				$txtCP=$Producto['CP'];
				$txtTelefono=$Producto['Telefono'];
				$txtContrasena=$Producto['Contrasena'];
				$txtEmail=$Producto['Email'];
				break;
			case 'Modify':
				$sentenciaSQL = $pdo->prepare("UPDATE cliente SET NombreUsuario=nombreusuario, Nombre = :nombre, Apellido = :apellido, 
				Ciudad = :ciudad, CP= :cp, Telefono= :telefono,  Contrasena= :contrasena, Email= :email WHERE ClienteID=:id"); 
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->bindParam(':nombreusuario', $txtNombreUsuario);
				$sentenciaSQL->bindParam(':nombre', $txtNombre);
				$sentenciaSQL->bindParam(':apellido', $txtApellido);
				$sentenciaSQL->bindParam(':ciudad', $txtCiudad);
				$sentenciaSQL->bindParam(':cp', $txtCP);
				$sentenciaSQL->bindParam(':telefono', $txtTelefono);
				$sentenciaSQL->bindParam(':contrasena', $txtContrasena);
				$sentenciaSQL->bindParam(':email', $txtEmail);
				$sentenciaSQL->execute();
				header('Location: index1.php');			
				break;						
			case 'Delete':
				$sentenciaSQL = $pdo->prepare("DELETE FROM cliente WHERE ClienteID=:id");
				$sentenciaSQL->bindParam(':id', $txtID);
				$sentenciaSQL->execute();
				header('Location: index1.php');
				break;
		} 
?>
<body>
<div class="wrapper">
	<?php include './menu.php';?>	
	<div class="main-panel">
		<div class="content">
			<div class="container-fluid">
				<h4 class="page-title">Clientes</h4>
					<div class="row">
						<div class="col-md-12">
								<br/>
							<div class="card">
								<div class="card-header">
									Datos del Cliente
								</div>
								<div class="card-body">
									<form method="POST" enctype="multipart/form-data">  <!--change method to POST, we use enctype to allow file submission-->
										
									<div class="form-group">
											<label for="txtNombreUsuario">Nombre de Usuario</label>
											<input type="hidden" name="txtID" value="<?php echo $txtID;?>">
											<input type="text" name="txtNombreUsuario" id="txtNombreUsuario" value="<?php echo $txtNombreUsuario; ?>" class="form-control single-input" placeholder="Nombre de usuario">
                                        </div>

										<div class="form-group">
											<label for="txtNombre">Nombre</label>
											<input type="text" name="txtNombre" id="txtNombre" value="<?php echo $txtNombre; ?>" class="form-control single-input" placeholder="Nombre">
                                        </div>

										<div class="form-group">
											<label for="txtApellido">Apellido</label>
											<input type="text" name="txtApellido" id="txtApellido" value="<?php echo $txtApellido; ?>" class="form-control progress-table-wrap" placeholder="Apellido">
                                        </div>
										<div class="form-group">
											<label for="txtCiudad">Ciudad</label>
											<input type="text" name="txtCiudad" value="<?php echo $txtCiudad; ?>" id="txtCiudad" class="form-control progress-table-wrap" 
											placeholder="Ciudad">
                                        </div>
										<div class="form-group">
											<label for="txtCP">CP</label>
											<input type="text" name="txtCP" value="<?php echo $txtCP; ?>" id="txtCP" class="form-control progress-table-wrap" 
											placeholder="CP">
                                        </div>
										<div class="form-group">
											<label for="txtTelefono">Telefono</label>
											<input type="text" name="txtTelefono" value="<?php echo $txtTelefono; ?>" id="txtTelefono" class="form-control progress-table-wrap" 
											placeholder="Telefono">
                                        </div>
										<div class="form-group">
											<label for="txtContrasena">Contraseña</label>
											<input type="text" name="txtContrasena" value="<?php echo $txtContrasena; ?>" id="txtContrasena" class="form-control progress-table-wrap" 
											placeholder="Contraseña">
                                        </div>
										<div class="form-group">
											<label for="txtEmail">Email</label>
											<input type="text" name="txtEmail" value="<?php echo $txtEmail; ?>" id="txtEmail" class="form-control progress-table-wrap" 
											placeholder="Email">
                                        </div>
										<div class="btn-group" role="group">		
											<button type="submit" name="accion" value="add" class="btn btn-success">Add</button>
											<button type="submit" name="accion" value="Modify" class="btn btn-primary">Modificar</button> 
											<button type="submit" name="accion" value="Cancel" class="btn btn-danger">Cancel</button>
										</div>		
									</form>
								</div>
							</div>
						</div>
					</div>
				<?php
				$sentenciaSQL = $pdo->prepare("SELECT * FROM cliente");
				$sentenciaSQL->execute();
				$listaProductos=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);
				?>
				<div class="row">
					<div class="col-md-12">
						<br/>
						<table class="MyTable  table cell-border display-compact" id="MyTable">
							<thead class="table-head">
								<tr>
								<th>ClienteID</th>
								<th>Nombre Usuario</th>
								<th>Nombre</th>
								<th>Apellido</th>
								<th>Ciudad</th>
                                <th>CP</th>
								<th>Telefono</th>
								<th>Contraseña</th>
								<th>Email</th>
								</tr>
							</thead>
						
							<tbody>
								<?php foreach ($listaProductos as $producto) {?>
								<tr class="table-row">
								<th><?php echo $producto['ClienteID'];?></th>
								<td><?php echo $producto['NombreUsuario'];?></td>
								<td><?php echo $producto['Nombre'];?></td>
								<td><?php echo $producto['Apellido'];?></td>
								<td><?php echo $producto['Ciudad']; ?></td>
								<td><?php echo $producto['CP']; ?></td>
								<td><?php echo $producto['Telefono']; ?></td>
								<td><?php echo $producto['Contrasena']; ?></td>
								<td><?php echo $producto['Email']; ?></td>
								<td><form method="post">
									<input type="hidden" name="txtID" value="<?php echo $producto['ClienteID']?>">
									<input type="submit" name="accion" value="Select" class="btn btn-primary">
									<input type="submit" name="accion" value="Delete" class="btn btn-danger">
								</form></td>


								</tr>
							<?php }?>
							</tbody>
						</table>
					</div>
				</div>
                    
			</div>
		</div>
	</div>
</div>
<?php include './footer.php';?>
<script>
$(document).ready(function () {
$('#MyTable').DataTable();
});
</script>
</body>

